package airline;

public class Airbus implements Flight {

	public void takeoff() {
		System.out.println("Welcome to airbus , Ready to takeoff");
		
	}

	public void takedown() {
		System.out.println("Ready for landing, Have a nice day");
		
	}

}
