package airline;

public class Boeing implements Flight {

	public void takeoff() {
		System.out.println("Welcome to boeing , Ready for takeoff");
		
	}

	public void takedown() {
		System.out.println("We are ready for landing");
		
	}

}
