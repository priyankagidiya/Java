package airline;

public interface Flight {
	void takeoff(); 
	void takedown();
		
	

}
