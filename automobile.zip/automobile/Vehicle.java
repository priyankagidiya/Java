package automobile;

public abstract class Vehicle {
	abstract int NoofWheels();
	
	
	

}
