package automobile;



public class Entry {
	
	public void start(Vehicle v) {
		
		System.out.println("Car can Ignite Using key");
	
		
	
	}

	
	public static void main(String[] args) {
		//Vehicle v = new Vehicle;// cannot create instance of parent class,it will show compilation error
		Car c = new Car();
		Vehicle v = new Car();
		
		 Bike b = new Bike();
		c.NoofWheels();
		c.TurningRadius();
		
		
		
		
		Car c1 = new Car();
		c1.start=(new Car());
		Vehicle c2 = (Car)c1;
		Bike b1 = new Bike();
		Vehicle c3 = (Bike)b1;
		b1.start=(new Bike());
		
		
		b.NoofWheels();
		b.MaxSpeed();
		b.start();
		
		
		
		//Integer Bike = new Integer(5);
		
		try {
			
			throw new Exception("e.errorMessage");
			

	}catch(Exception e ) {
		
		
		
		System.out.println("Exception throw in Bike "+ e.getMessage());
		
	}

}
}
