package automobile;

public class Car extends Vehicle {

	





	public Car start;





	@Override
	int NoofWheels() {
		System.out.println("Number of Wheels must be 4");
		return 4;
	}

	
	

	
	void TurningRadius() {
		System.out.println("Car has double turning radius");
			
	}

	public void start() {
		// TODO Auto-generated method stub
		
	}
		
		
	

	
		
	}
	

	

