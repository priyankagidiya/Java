package automobile;

public class Bike extends Vehicle {

	

	public Bike start; 
		
	


	int NoofWheels() {
		System.out.println("Number of Wheels must be 2");
		return 2;
	}

	
	int MaxSpeed() {
		System.out.println("Maximum Speed is 70mph");
		return 70;
	}

	
	
	public void start() {
		
	}
	
	
}
